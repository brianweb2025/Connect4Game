Fourfall — offline package

Play with no internet
  Double-click index.html. It opens in your browser and does not need a connection.

Publish on any site
  Upload this entire folder to GitHub Pages, Netlify, Cloudflare Pages, itch.io,
  Neocities, or any host that serves files. Keep the file names as they are.
  After one visit, the saved copy keeps working offline.

Nothing here needs Node, a database, or a build step.
